#!/bin/sh
# Grants QubiqCore the network capabilities the VPN tunnel needs.
# The DEB sets them on install; ZIP users run this once after extracting:
#   ./grant-caps.sh
set -eu

cd "$(dirname "$0")"
CORE="$(pwd)/QubiqCore"
if [ ! -f "$CORE" ]; then
    echo "QubiqCore not found next to this script" >&2
    exit 1
fi

if [ "$(id -u)" -eq 0 ]; then
    setcap cap_net_admin,cap_net_raw+eip "$CORE"
elif command -v pkexec >/dev/null 2>&1; then
    pkexec setcap cap_net_admin,cap_net_raw+eip "$CORE"
else
    sudo setcap cap_net_admin,cap_net_raw+eip "$CORE"
fi

getcap "$CORE"
echo "QubiqCore is ready — start the app and connect."
